//when the webpage is loaded
jQuery(document).ready(function($) {
	alert("welcome to Empolyee Registration form Please fill the details");
});