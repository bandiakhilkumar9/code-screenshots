<?php

namespace Drupal\ajaxform\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Entity\ContentEntityType;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Config\ConfigFactoryInterface;

/**
 * Provides a default form.
 */
class Ajaxform extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'ajax_form';
  }
  protected function getEditableConfigNames() {
    return [
      static::SETTINGS,
    ];
  }
  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    $countries = [1 => "India",2 => "UK", 3 => "US"]; 
    // $countries = getYourCountiresList  funtion call and get array of country options lile [1 => "India", 2 => "USA"];
      $form['Country'] = [
       '#type' => 'select',
       '#title' => t('Country'),
       '#description' => t('Country'),
       '#required' => TRUE,
       '#options' => $countries,
      // '#default_value' => setInConfigandGEtVAlue,
       '#ajax' => ['callback' => [$this, 'getStates'],  'event' => 'change',
                   'method' => 'html',
                   'wrapper' => 'states-to-update',
                   'progress' => [
                     'type' => 'throbber',
                      'message' => NULL,
                   ],
                 ],
     ];
      $states = [1 => ["TELANGANA" => "TELANGANA","ANDHRAPRADESH" => "ANDHRAPRADESH" ],
      2 => ["UP" => "UP","MH" => "MH" ],
      3 => ["Tamilnadu" => "Tamilnadu","Kerela" => "Kerela" ]]
      ;

    // if($default_country != "") { load default states of selected country by get the default value of country (setInConfigandGEtVAlue)
      // $states = $this->getStatesByCountry($default_country);
 
    // }
    
     $form['state'] = array(
       '#title' => t('State'),
       '#type' => 'select',
       '#description' => t('Select the state'),
       '#options' => $states,
      // '#default_value' => setInConfigandGEtVAlue,
       '#attributes' => ["id" => 'states-to-update'],
       '#multiple' => TRUE,
       '#validated' => TRUE
     );
     $form['toggle_me'] = array(
      '#type' => 'checkbox',
      '#title' => t('Tick this box to type'),
    );
    $form['settings'] = array(
      '#type' => 'textfield',
      '#states' => array(
        // Only show this field when the 'toggle_me' checkbox is enabled.
        'visible' => array(
          ':input[name="toggle_me"]' => array(
            'checked' => TRUE,
          ),
        ),
      ),
    );
    $form['submit'] = array(
       '#type' => 'submit',
       '#value' => t('Submit'),
     );
    
     return $form;
   }
   public function validateForm(array &$form, FormStateInterface $form_state) {
  }
  /**
     * {@inheritdoc}
     */

public function getStates(array &$element, FormStateInterface $form_state) {
    $triggeringElement = $form_state->getTriggeringElement();
    $value = $triggeringElement['#value'];
    $states = $this->getStatesByCountry($value);
    $wrapper_id = $triggeringElement["#ajax"]["wrapper"];
    $renderedField = '';
    foreach ($states as $key => $value) {
      $renderedField .= "<option value='".$key."'>".$value."</option>";
    }
    $response = new AjaxResponse();
    $response->addCommand(new HtmlCommand("#".$wrapper_id, $renderedField));
    return $response;
  }

  public function getStatesByCountry($default_country ) {
    //add you logic return states by country
    if ($default_country == 1){
       $states =  ["TELANGANA" => "TELANGANA","ANDHRAPRADESH" => "ANDHRAPRADESH" ];
    }
    if ($default_country == 2){
      $states =   ["UP" => "UP","MH" => "MH" ];
   }
   if ($default_country == 3){
    $states =  ["Tamilnadu" => "Tamilnadu","Kerela" => "Kerela" ];
 }
    return $states;
  }
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $this->configFactory->getEditable(static::SETTINGS)
      ->set('Country', $form_state->getValue('Country'))
      ->set('state', $form_state->getValue('state'))
      ->save();
      parent::submitForm($form, $form_state);
   }
}