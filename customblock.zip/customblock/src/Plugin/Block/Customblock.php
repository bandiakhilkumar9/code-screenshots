<?php

namespace Drupal\customblock\Plugin\Block;
 
use Drupal\Core\Block\BlockBase;
 
/**
 * Creates a 'customblock' Block
 * @Block(
 * id = "custom_block",
 * admin_label = @Translation("customblock"),
 * )
 */
class CustomBlock extends BlockBase {
 
    /**
     * {@inheritdoc}
     */
    public function build() {
        return [
          '#markup' => $this->t('My custom block'),
        ];
      }
    
 
}
