<?php
namespace Drupal\customblockform\Form;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
 
class Registrationform extends ConfigFormBase {
/**
   * Config settings.
   *
   * @var string
   */
  const SETTINGS = 'customblockform.settings';
 
  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'Registration_form_settings';
  }
 
  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      static::SETTINGS,
    ];
  }
 
  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config(static::SETTINGS);
 
  $form['empolyee_name'] = array(
      '#type' => 'textfield',
      '#title' => $this->t('Empolyee Name:'),
      '#required' => TRUE,
      '#default_value' => $config->get('empolyee_name'),
    );
    $form['empolyee_id'] = array(
      '#type' => 'textfield',
      '#title' => $this->t('Empolyee ID:'),
      '#required' => TRUE,
      '#default_value' => $config->get('empolyee_id'),
    );
    $form['empolyee_number'] = array(
      '#type' => 'tel',
      '#title' => $this->t('Empolyee mobile number:'),
      '#required' => TRUE,
      '#default_value' => $config->get('empolyee_number'),
    );
    $form['empolyee_mail'] = array(
      '#type' => 'email',
      '#title' => $this->t('Empolyee Email ID:'),
      '#required' => TRUE,
      '#default_value' => $config->get('empolyee_mail'),
    );

    return parent::buildForm($form, $form_state);
  }
 
   /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $this->configFactory->getEditable(static::SETTINGS)
      // Set the submitted configuration setting.
      ->set('empolyee_name', $form_state->getValue('empolyee_name'))
      // You can set multiple configurations at once by making
      // multiple calls to set().
      ->set('empolyee_id', $form_state->getValue('empolyee_id'))
      ->set('empolyee_number', $form_state->getValue('empolyee_number'))
      ->set('empolyee_mail', $form_state->getValue('empolyee_mail'))
      ->save();
 
    parent::submitForm($form, $form_state);
  }
  
  public function validateForm(array &$form, FormStateInterface $form_state) {

    if(preg_match('/[^A-Za-z]/', $form_state->getValue('empolyee_name'))) {
      $form_state->setErrorByName('empolyee_name', $this->t('Empolyee name should contain only alphabets'));
    }
    if (strlen($form_state->getValue('empolyee_name')) < 2 && strlen($form_state->getValue('empolyee_name')) >0) {
      $form_state->setErrorByName('empolyee_name', $this->t(' Empolyee name is too short'));
    }
  
  if (strlen($form_state->getValue('empolyee_id')) < 2 && strlen($form_state->getValue('empolyee_id')) >0)  {
      $form_state->setErrorByName('empolyee_id', $this->t('Please enter valid Empolyee ID.'));
    }
   if (!is_numeric($form_state->getValue('empolyee_number'))   && strlen($form_state->getValue('empolyee_number')) >0)  {
      $form_state->setErrorByName('empolyee_number', $this->t('Please enter  Valid Empolyee mobile number.'));
    }
    if (empty($form_state->getValue('empolyee_mail'))) {
      $form_state->setErrorByName('empolyee_mail', $this->t('Empolyee Email ID.'));
    }
  } 
  }