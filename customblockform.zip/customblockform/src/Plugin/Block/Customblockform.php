<?php
 
/**
 * @file
 */
namespace Drupal\customblockform\Plugin\Block;
use Drupal\Core\Form\FormInterface;
 
use Drupal\Core\Block\BlockBase;
 
/**
 * Creates a 'customblockform' Block
 * @Block(
 * id = "custom_block_form",
 * admin_label = @Translation("custom block form"),
 * )
 */
class Customblockform extends BlockBase {
 
    /**
     * {@inheritdoc}
     */
    public function build() {
      $form = \Drupal::formBuilder()->getForm('Drupal\customblockform\Form\Registrationform');
      return $form;
    }
 
}