<?php

namespace Drupal\Empolyeedata\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides a 'EmpolyeedataBlock' block.
 *
 * @Block(
 *  id = "Empolyeedata_block",
 *  admin_label = @Translation("Empolyeedata block"),
 * )
 */
class EmpolyeedataBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {
    ////$build = [];
    //$build['Empolyeedata_block']['#markup'] = 'Implement EmpolyeedataBlock.';

    $form = \Drupal::formBuilder()->getForm('Drupal\Empolyeedata\Form\EmpolyeedataForm');

    return $form;
  }

}
