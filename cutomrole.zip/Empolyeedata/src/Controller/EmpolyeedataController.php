<?php

namespace Drupal\Empolyeedata\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Class EmpolyeedataController.
 *
 * @package Drupal\Empolyeedata\Controller
 */
class EmpolyeedataController extends ControllerBase {

  /**
   * Display.
   *
   * @return string
   *   Return Hello string.
   */
  public function display() {
    return [
      '#type' => 'markup',
      '#markup' => $this->t('This page contain all inforamtion about my data ')
    ];
  }

}
