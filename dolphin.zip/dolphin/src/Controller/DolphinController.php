<?php
namespace Drupal\dolphin\Controller;


use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Config\ConfigFactoryInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Url;
use Drupal\Core\Render\Markup;
use Drupal\user\Entity\User;

class DolphinController extends ControllerBase  {
	public function display() {
		$results = \Drupal::service('config.factory')->getEditable('dolphin.settings')->get();
		//print_r($results);
		//exit;
	 $output = array(
			'#theme' => 'empolyee_list',    // Here you can write #type also instead of #theme.
			'#users' => $results,
			 );
			return $output;
	   
			$form['table'] = [
				'#type' => 'table',
				'#header' => $header_table,
				'#rows' => $k1,
				'#empty' => t('No users found'),
			];
			return $form;
  
	}
  }
  