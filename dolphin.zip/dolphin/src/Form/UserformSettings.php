<?php

namespace Drupal\dolphin\Form;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Ajax\AjaxResponse;

class UserformSettings extends ConfigFormBase {
/**
   * Config settings.
   *
   * @var string
   */
  const SETTINGS = 'dolphin.settings';
 
  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'Userform_settings';
  }
 
  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      static::SETTINGS,
    ];
  }
 
  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config(static::SETTINGS);
 
    $form['empolyee_name'] = array(
      '#type' => 'textfield',
      '#title' => $this->t('Empolyee Name:'),
      '#required' => TRUE,
      '#default_value' => $config->get('empolyee_name'),
    );
    $form['empolyee_id'] = array(
      '#type' => 'textfield',
      '#title' => $this->t('Empolyee ID:'),
      '#required' => TRUE,
      '#default_value' => $config->get('empolyee_id'),
    );
    $form['empolyee_number'] = array(
      '#type' => 'tel',
      '#title' => $this->t('Empolyee mobile number:'),
      '#required' => TRUE,
      '#default_value' => $config->get('empolyee_number'),
    );
    $form['empolyee_mail'] = array(
      '#type' => 'email',
      '#title' => $this->t('Empolyee Email ID:'),
      '#required' => TRUE,
      '#default_value' => $config->get('empolyee_mail'),
    );
    $countries = [1 => "India",2 => "UK", 3 => "US"]; 
    // $countries = getYourCountiresList  funtion call and get array of country options lile [1 => "India", 2 => "USA"];
      $form['Country'] = [
       '#type' => 'select',
       '#title' => t('Country'),
       '#description' => t('Country'),
       '#required' => TRUE,
       '#options' => $countries,
      // '#default_value' => setInConfigandGEtVAlue,
       '#ajax' => ['callback' => [$this, 'getStates'],  'event' => 'change',
                   'method' => 'html',
                   'wrapper' => 'states-to-update',
                   'progress' => [
                     'type' => 'throbber',
                      'message' => NULL,
                   ],
                 ],
     ];
      $states = [1 => ["TELANGANA" => "TELANGANA","ANDHRAPRADESH" => "ANDHRAPRADESH" ],
      2 => ["England" => "England","Scotland" => "Scotland" ],
      3 => ["California" => "California","Washington" => "Washington" ]]
      ;

    // if($default_country != "") { load default states of selected country by get the default value of country (setInConfigandGEtVAlue)
      // $states = $this->getStatesByCountry($default_country);
 
    // }
    
     $form['state'] = array(
       '#title' => t('State'),
       '#type' => 'select',
       '#description' => t('Select the state'),
       '#options' => $states,
      // '#default_value' => setInConfigandGEtVAlue,
       '#attributes' => ["id" => 'states-to-update'],
       '#multiple' => TRUE,
       '#validated' => TRUE
     );
     $form['toggle_me'] = array(
      '#type' => 'checkbox',
      '#title' => t('Tick this box to type'),
    );
    $form['settings'] = array(
      '#type' => 'textfield',
      '#states' => array(
        // Only show this field when the 'toggle_me' checkbox is enabled.
        'visible' => array(
          ':input[name="toggle_me"]' => array(
            'checked' => TRUE,
          ),
        ),
      ),
    );
    $form['#attributes']['class'][] = 'empolyeeform';
    $form['#attached']['library'][] = 'customform/empolyeeform';
    return parent::buildForm($form, $form_state);
  }
 
  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $this->configFactory->getEditable(static::SETTINGS)
      // Set the submitted configuration setting.
      ->set('empolyee_name', $form_state->getValue('empolyee_name'))
      // You can set multiple configurations at once by making
      // multiple calls to set().
      ->set('empolyee_id', $form_state->getValue('empolyee_id'))
      ->set('empolyee_number', $form_state->getValue('empolyee_number'))
      ->set('empolyee_mail', $form_state->getValue('empolyee_mail'))
      ->set('Country', $form_state->getValue('Country'))
      ->set('state', $form_state->getValue('state'))
      ->save();
 
    parent::submitForm($form, $form_state);
  }
  
  public function getStates(array &$element, FormStateInterface $form_state) {
    $triggeringElement = $form_state->getTriggeringElement();
    $value = $triggeringElement['#value'];
    $states = $this->getStatesByCountry($value);
    $wrapper_id = $triggeringElement["#ajax"]["wrapper"];
    $renderedField = '';
    foreach ($states as $key => $value) {
      $renderedField .= "<option value='".$key."'>".$value."</option>";
    }
    $response = new AjaxResponse();
    $response->addCommand(new HtmlCommand("#".$wrapper_id, $renderedField));
    return $response;
  }

  public function getStatesByCountry($default_country ) {
    //add you logic return states by country
    if ($default_country == 1){
       $states =  ["TELANGANA" => "TELANGANA","ANDHRAPRADESH" => "ANDHRAPRADESH" ];
    }
    if ($default_country == 2){
      $states =   ["England" => "England","Scotland" => "Scotland" ];
   }
   if ($default_country == 3){
    $states =  ["California" => "California","Washington" => "Washington"];
 }
    return $states;
  }
}