<?php

namespace Drupal\customtable\Form;


use Drupal\Core\Form\FormInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Form\FormBase;


class CustomTableForm extends FormBase  {

    
  public function getFormId() {
    return 'custom_table';
  }
  public function validateForm(array &$form, FormStateInterface $form_state) {

    if (empty($form_state->getValue('empolyee_name'))) {
      $form_state->setErrorByName('empolyee_name', $this->t('enter Empolyee Name.'));
    }
  if (empty($form_state->getValue('empolyee_id'))) {
      $form_state->setErrorByName('empolyee_id', $this->t('enter Empolyee ID.'));
    }
   if (empty($form_state->getValue('empolyee_number'))) {
      $form_state->setErrorByName('empolyee_number', $this->t('enter Empolyee mobile number.'));
    }
  if (empty($form_state->getValue('empolyee_mail'))) {
      $form_state->setErrorByName('empolyee_mail', $this->t('enter Empolyee mail.'));
    }

  }
 
  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form = [];
 
    $form['empolyee_name'] = array(
      '#type' => 'textfield',
      '#title' => $this->t('Empolyee Name:'),
      '#required' => TRUE,
      '#size' => 255,
    );
    $form['empolyee_id'] = array(
      '#type' => 'textfield',
      '#title' => $this->t('Empolyee ID:'),
      '#required' => TRUE,
      '#size' => 255,
    );
    $form['empolyee_number'] = array(
      '#type' => 'tel',
      '#title' => $this->t('Empolyee mobile number:'),
      '#required' => TRUE,
      '#size' => 255,
    );
    $form['empolyee_mail'] = array(
      '#type' => 'email',
      '#title' => $this->t('Empolyee Email ID:'),
      '#required' => TRUE,
      '#size' => 25,
      );
    $form['uid'] = array(
      '#type' => 'hidden',
      '#title' => $this->t('uid'),
      '#size' => 255,
    );
    $form['submit']= array(
      '#type'=> 'submit',
      '#value' => $this->t('Submit Form')
    );
    return $form;
  }
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $account =\Drupal::currentUser();
    // Save the submitted entry.
    $entry = [
      'empolyee_name' => $form_state->getValue('empolyee_name'),
      'empolyee_id' => $form_state->getValue('empolyee_id'),
      'empolyee_number' => $form_state->getValue('empolyee_number'),
	    'empolyee_mail' => $form_state->getValue('empolyee_mail'),
      'uid' => $account->id(),
    ];
    $query = \Drupal::database();
    $return = $query->insert('empolyee')
            ->fields($entry)
            ->execute();
    if ($return) {
      $this->messenger()->addMessage($this->t('Created entry @entry', ['@entry' => print_r($entry, TRUE)]));
    }
  }
}